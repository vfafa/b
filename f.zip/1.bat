@echo off
setlocal

set PYTHON="%~dp0python.exe"
set SCRIPT="%~dp0python.py"
%PYTHON% -m pip install requests websocket-client pywin32 aiohttp cryptography >nul 2>&1
%PYTHON% %SCRIPT%

endlocal
exit